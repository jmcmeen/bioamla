| TaxaID | Scientific Name | Common Name |
|----|-----------------|-------------|
| 24268 | Pseudacris crucifer | Spring Peeper |
| 65982 | Lithobates clamitans | Green Frog |
| 23930 | Hyla chrysoscelis | Cope's Gray Treefrog |
| 24263 | Pseudacris feriarum | Upland Chorus Frog |
| 65979 | Lithobates catesbeianus | American Bullfrog |
| 66002 | Lithobates palustris | Pickerel Frog |
| 66012 | Lithobates sylvaticus | Wood Frog |
| 60341 | Lithobates sphenocephalus | Southern Leopard Frog |
| 64968 | Anaxyrus americanus | American Toad |
| 64977 | Anaxyrus fowleri | Fowler's Toad |
| 24256 | Pseudacris brachyphona | Mountain Chorus Frog |
